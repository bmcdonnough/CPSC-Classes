On my honor, I have neither given nor received aid on this SDE, including assistance from AI tools.

Archive:
    README.txt - explains the archive structure and the contents of each file
    OCaml Source Code - contains all of the required and helper functions for this assignment.
    log.pdf - screenshots of sample uses to test each required function.

