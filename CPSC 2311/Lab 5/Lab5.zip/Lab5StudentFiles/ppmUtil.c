
void writeHeader(FILE* image, header_t head)
{
    
}
void writePixels(FILE* image,pixel_t* p, header_t head)
{
   
}

pixel_t* readPixels(FILE* image, header_t head)
{
    

}

pixel_t* read(FILE* in, header_t *head)
{
    
}
void write(FILE* image, header_t head, pixel_t* pix)
{
   

}

pixel_t* allocatePixMemory(header_t h)
{
   
}

void ckComment(FILE* in)
{
    
}

void readHeader(FILE* in, header_t *hdr)
{
}

void freeMemory(pixel_t* pix)
{
    
}
